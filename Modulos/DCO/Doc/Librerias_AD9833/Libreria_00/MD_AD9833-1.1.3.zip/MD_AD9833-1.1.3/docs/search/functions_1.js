var searchData=
[
  ['getactivefrequency',['getActiveFrequency',['../class_m_d___a_d9833.html#a947eef2d0f5ccb8e56441b741f1d7487',1,'MD_AD9833']]],
  ['getactivephase',['getActivePhase',['../class_m_d___a_d9833.html#ab8663778999fd5b1262f7f2661bd4bb9',1,'MD_AD9833']]],
  ['getfrequency',['getFrequency',['../class_m_d___a_d9833.html#abfb44b908e3efea8ae0422f89b063a7e',1,'MD_AD9833']]],
  ['getmode',['getMode',['../class_m_d___a_d9833.html#a18b799d4b2f1162bfcd68a2c81f6c571',1,'MD_AD9833']]],
  ['getphase',['getPhase',['../class_m_d___a_d9833.html#aa825c7a6896ba1fc1a2b2943053f8336',1,'MD_AD9833']]]
];
